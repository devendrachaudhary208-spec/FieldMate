package com.fieldmate.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.IntentSender;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import com.google.mlkit.vision.documentscanner.GmsDocumentScanner;
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

/**
 * Service Engineer Toolkit — the whole app is the web page in assets/www.
 * This activity hosts it in a WebView and adds what a browser page can't do on its own:
 * document scanner, camera / gallery for bill photos, saving PDF / Excel to Downloads, and the back button.
 */
public class MainActivity extends Activity {

    private static final String HOME = "https://appassets.androidplatform.net/assets/www/index.html";
    private static final int REQ_FILE = 11;
    private static final int REQ_SCAN = 12;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);

        // Serve assets/www from a proper https origin so localStorage and IndexedDB persist.
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                String accept = params.getAcceptTypes() == null ? "" : TextUtils.join(",", params.getAcceptTypes());
                if (!accept.contains("image")) return openChooser(params, false);
                askPhotoSource(params);
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl(HOME);
    }

    /** Bills: scan (auto crop, like a scanner), plain camera photo, or pick from gallery / files. */
    private void askPhotoSource(final WebChromeClient.FileChooserParams params) {
        String[] items = {"Scan document (auto crop, scanner copy)", "Camera photo", "Gallery / Files"};
        new AlertDialog.Builder(this)
                .setTitle("Add bill")
                .setItems(items, (d, which) -> {
                    if (which == 0) startScanner(params);
                    else if (which == 1) openCamera(params);
                    else openChooser(params, true);
                })
                .setOnCancelListener(d -> cancelPick())
                .show();
    }

    private void cancelPick() {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        fileCallback = null;
    }

    /** Google ML Kit document scanner: finds the paper edges, crops, straightens and cleans the page. */
    private void startScanner(final WebChromeClient.FileChooserParams params) {
        GmsDocumentScannerOptions options = new GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(10)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG, GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build();
        GmsDocumentScanner scanner = GmsDocumentScanning.getClient(options);
        scanner.getStartScanIntent(this)
                .addOnSuccessListener(sender -> {
                    try {
                        startIntentSenderForResult(sender, REQ_SCAN, null, 0, 0, 0);
                    } catch (IntentSender.SendIntentException e) {
                        Toast.makeText(this, "Scanner not available, opening camera", Toast.LENGTH_SHORT).show();
                        openCamera(params);
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Scanner not available on this phone, opening camera", Toast.LENGTH_LONG).show();
                    openCamera(params);
                });
    }

    private void openCamera(WebChromeClient.FileChooserParams params) {
        try {
            File photo = File.createTempFile("bill_", ".jpg", getCacheDir());
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".files", photo);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(cam, REQ_FILE);
        } catch (Exception e) {
            cameraUri = null;
            openChooser(params, true);
        }
    }

    /** Gallery / files picker (with the camera offered as well for bill photos). */
    private boolean openChooser(WebChromeClient.FileChooserParams params, boolean wantsImages) {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        if (wantsImages) {
            pick.setType("*/*");
            pick.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "application/pdf"});
        } else {
            pick.setType("*/*");
        }
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);

        Intent[] extra = new Intent[0];
        cameraUri = null;
        if (wantsImages) {
            try {
                File photo = File.createTempFile("bill_", ".jpg", getCacheDir());
                cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".files", photo);
                Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                extra = new Intent[]{cam};
            } catch (IOException e) {
                cameraUri = null;
            }
        }
        Intent chooser = Intent.createChooser(pick, wantsImages ? "Take photo or pick bill" : "Pick file");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, extra);
        try {
            startActivityForResult(chooser, REQ_FILE);
            return true;
        } catch (Exception e) {
            cancelPick();
            Toast.makeText(this, "No app found to pick files", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (fileCallback == null) return;
        if (requestCode == REQ_SCAN) {
            Uri[] scanned = null;
            if (resultCode == RESULT_OK && data != null) {
                GmsDocumentScanningResult res = GmsDocumentScanningResult.fromActivityResultIntent(data);
                if (res != null) {
                    List<GmsDocumentScanningResult.Page> pages = res.getPages();
                    if (pages != null && pages.size() > 1 && res.getPdf() != null) {
                        scanned = new Uri[]{toContent(res.getPdf().getUri())};       // several pages: one PDF
                    } else if (pages != null && !pages.isEmpty()) {
                        scanned = new Uri[]{toContent(pages.get(0).getImageUri())};  // one page: scanned image
                    }
                }
            }
            fileCallback.onReceiveValue(scanned);
            fileCallback = null;
            return;
        }
        if (requestCode != REQ_FILE) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getClipData() != null) {
                ClipData cd = data.getClipData();
                result = new Uri[cd.getItemCount()];
                for (int i = 0; i < cd.getItemCount(); i++) result[i] = cd.getItemAt(i).getUri();
            } else if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            } else if (cameraUri != null) {
                result = new Uri[]{cameraUri};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    /** Scanner results are files in the app cache; hand them to the page as content:// URIs. */
    private Uri toContent(Uri u) {
        if (u == null || !"file".equals(u.getScheme())) return u;
        try {
            return FileProvider.getUriForFile(this, getPackageName() + ".files", new File(u.getPath()));
        } catch (Exception e) {
            return u;
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__back && window.__back()) ? 'y' : 'n'", value -> {
            if (!"\"y\"".equals(value)) closeApp();
        });
    }

    private void closeApp() {
        super.onBackPressed();
    }

    /** Called from the page: window.AndroidBridge.saveFile(name, base64, mime). */
    private class Bridge {
        @JavascriptInterface
        public String saveFile(String name, String base64, String mime) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                Uri uri;
                String where;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FieldMate");
                    uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) throw new IOException("Could not create file");
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        if (os == null) throw new IOException("Could not open file");
                        os.write(bytes);
                    }
                    where = "Downloads/FieldMate";
                } else {
                    File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "FieldMate");
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create folder");
                    File f = new File(dir, name);
                    try (FileOutputStream os = new FileOutputStream(f)) { os.write(bytes); }
                    uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);
                    where = "app storage (Android/data/" + getPackageName() + ")";
                }
                final Uri shareUri = uri;
                final String shownWhere = where;
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Saved to " + shownWhere, Toast.LENGTH_LONG).show();
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(mime);
                    send.putExtra(Intent.EXTRA_STREAM, shareUri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(Intent.createChooser(send, "Send " + name)); } catch (Exception ignored) { }
                });
                return "OK:" + where + "/" + name;
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            }
        }
    }
}
