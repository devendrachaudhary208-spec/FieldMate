/* Service Engineer Toolkit — Android app bridge.
   Runs before the app script. Replaces the claude.ai runtime with on-phone storage:
   - data: the app's own localStorage store (claude.use("db") returns null)
   - bill photos / PDFs: IndexedDB on the phone
   - saving PDF / Excel: Android Downloads/FieldMate + share sheet */
(function () {
  const DBN = "toolkit-files", ST = "files";
  const urls = new Map();
  const open = () => new Promise((res, rej) => { const r = indexedDB.open(DBN, 1); r.onupgradeneeded = () => r.result.createObjectStore(ST); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  const tx = async (mode, fn) => { const db = await open(); return new Promise((res, rej) => { const t = db.transaction(ST, mode), s = t.objectStore(ST); const out = fn(s); t.oncomplete = () => res(out && out.result !== undefined ? out.result : out); t.onerror = () => rej(t.error); }); };
  const ready = (async () => {
    try {
      const db = await open();
      await new Promise(res => { const t = db.transaction(ST, "readonly"); const c = t.objectStore(ST).openCursor(); c.onsuccess = () => { const cur = c.result; if (!cur) return res(); urls.set(cur.key, URL.createObjectURL(cur.value.blob)); cur.continue(); }; c.onerror = () => res(); });
    } catch (e) { console.warn("file store unavailable", e); }
  })();
  const uid = () => "f" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const assets = {
    async upload(blob, opts = {}) {
      const id = uid(), type = opts.type || blob.type || "application/octet-stream";
      const b = blob instanceof Blob ? blob : new Blob([blob], { type });
      await tx("readwrite", s => s.put({ blob: b, type }, id));
      const url = URL.createObjectURL(b); urls.set(id, url);
      return { id, url };
    },
    async delete(id) { await tx("readwrite", s => s.delete(id)); const u = urls.get(id); if (u) URL.revokeObjectURL(u); urls.delete(id); },
    urlFor: id => urls.get(id),
    async bytes(id) { const rec = await tx("readonly", s => s.get(id)); return rec && rec.blob ? await rec.blob.arrayBuffer() : null; },
  };
  const MIME = { pdf: "application/pdf", xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", json: "application/json", csv: "text/csv" };
  const toB64 = data => { const u = data instanceof Uint8Array ? data : new Uint8Array(data); let s = ""; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };
  const downloads = {
    async save({ filename, data }) {
      const ext = (filename.split(".").pop() || "").toLowerCase(), mime = MIME[ext] || "application/octet-stream";
      if (window.AndroidBridge) {
        const r = window.AndroidBridge.saveFile(filename, toB64(data), mime);
        if (String(r).startsWith("ERR")) throw new Error(r);
        return;
      }
      const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([data], { type: mime })); a.download = filename; document.body.append(a); a.click(); a.remove();
    },
  };
  window.claude = { use: async cap => { if (cap === "assets") { await ready; return assets; } if (cap === "downloads") return downloads; return null; } };
})();
