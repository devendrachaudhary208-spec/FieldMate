# FieldMate – Android app

FieldMate as a real Android app. It works offline, and your data stays on the phone.

- **Bill photos:** tapping **+ Photo or PDF** gives three choices:
  - **Scan document:** Google's scanner finds the paper edges, crops, straightens and cleans the page like CamScanner. Several pages become one PDF.
  - **Camera photo:** a normal photo.
  - **Gallery / Files:** pick an existing photo or PDF.
- **Scan copy switch:** also next to the photo button. With it on, every photo is cropped and turned into a clean scanner-style image.
- **Saved files:** PDF and Excel files go to **Downloads / FieldMate**, and the share sheet opens so you can send them on WhatsApp or by email.
- **Back button:** closes the open form first, then goes back to Home.

---

## Way 1: Build with Android Studio (on your laptop)

1. Install **Android Studio** from https://developer.android.com/studio (free).
2. Unzip `ServiceToolkit-android.zip`.
3. Open Android Studio, choose **Open**, and select the `ServiceToolkit` folder.
4. Wait for **Gradle sync** to finish at the bottom of the window. The first time, it downloads about 1 GB.
5. From the menu choose **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
6. When it finishes, click **locate**. You'll find `app-debug.apk`.
7. Copy the APK to your phone by USB, Google Drive or WhatsApp to yourself, then tap it to install.
   - Allow **Install unknown apps** when Android asks.
   - If Play Protect warns about an unknown developer, tap **Install anyway**. The developer is you.

Quicker option: connect the phone by USB with **USB debugging** on, and press the green **Run ▶** button.

## Way 2: Build online with GitHub (nothing to install)

1. Make a free account at https://github.com and create a **private** repository.
2. Click **Add file → Upload files**. Drag in **everything** from the unzipped `ServiceToolkit` folder, including the `.github` folder, then click **Commit**.
3. Open the **Actions** tab. "Build APK" runs automatically and takes about 5 minutes.
4. Open the finished run. Under **Artifacts**, download **ServiceToolkit-apk**, unzip it, and install the APK on your phone as in step 7 above.

---

## Notes on the scanner

The scanner uses Google Play services, which almost every Android phone has. The first time you use it, the phone downloads the scanner part automatically, which takes a few seconds and needs internet once. If a phone doesn't support it, the app opens the normal camera instead.

## Move your data from the web version into the app

1. In the web toolkit, go to **Settings (gear) → Save backup**. You get a `toolkit-backup-DATE.json` file.
2. Send that file to your phone.
3. In the app, go to **Settings → Restore backup**, pick the file, then tap **Restore now**.

Trips, bills, claims, attendance, service reports, leave, customers, holidays and settings all come across. Bill photos don't, because they stay where they were taken.

Take a backup now and then (Settings → Save backup) and keep it in Google Drive. If you change phones, restore it there.

## Updating the app later

When the toolkit changes, only the web page inside the app changes:
`app/src/main/assets/www/index.html`

Replace that file with the new version and build again (Way 1 or Way 2). Your data stays, as long as you install the new APK over the old one without uninstalling.

## Project contents

- `app/src/main/assets/www/`: the toolkit page (`index.html`), the phone bridge (`android-shim.js`) and the PDF and Excel libraries (`lib/`)
- `app/src/main/java/.../MainActivity.java`: WebView host with camera/gallery, saving to Downloads, share sheet and back button
- `.github/workflows/build-apk.yml`: the online build used in Way 2
